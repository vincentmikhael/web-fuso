@extends('layouts.main')

@section('content')

    {!!$service->content!!}
    
@endsection
