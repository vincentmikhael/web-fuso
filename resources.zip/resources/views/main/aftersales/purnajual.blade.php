@extends('layouts.main')

@section('content')

    {!!$purnajual->content!!}

@endsection
